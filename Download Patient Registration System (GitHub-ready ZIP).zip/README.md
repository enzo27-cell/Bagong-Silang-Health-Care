# Patient Appointment Request (Frontend Demo)

A simple patient-only appointment request form built with **HTML, CSS, and vanilla JavaScript**. No framework or build step is required.

## Files

- `index.html` - form structure and fields
- `styles.css` - responsive styling
- `script.js` - conditional fields, basic validation, and demo confirmation

## Run locally

1. Download or clone this repository.
2. Keep all three files in the same folder.
3. Open `index.html` in a browser. (VS Code users can also use the Live Server extension.)

## Upload to GitHub

Create a new GitHub repository, then upload these files while keeping them together in the repository root. GitHub Pages can host this static frontend: in repository **Settings → Pages**, choose the branch and root folder. This demo does not require PHP to display.

## Important: demo only

This is a **frontend prototype**. It validates the form and displays a temporary confirmation in the browser, but it does not send, store, or book patient requests. Do not enter real patient or medical information into a public demo. Before using real patients, connect the form to a secure backend (for example PHP) and a database, add server-side validation, authentication and staff access controls, HTTPS, appropriate privacy notices and retention controls. Do not rely on browser-only JavaScript for security.

The PWD, senior citizen, and pregnancy selections are flags for staff review, not an automatic medical triage decision. Authorized health center staff must determine queue priority under clinic policy. A requested date/time is not a confirmed appointment.
