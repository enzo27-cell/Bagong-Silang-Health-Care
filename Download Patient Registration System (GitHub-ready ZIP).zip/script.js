// Patient appointment form interactions. No patient data is sent or stored.
const form = document.getElementById('patientForm');
const conditionFields = document.getElementById('conditionFields');
const conditionInput = document.getElementById('condition');
const specialistInput = document.getElementById('specialist');
const ordinaryNote = document.getElementById('ordinaryNote');
const message = document.getElementById('formMessage');
const confirmation = document.getElementById('confirmation');
const dateInput = document.getElementById('preferredDate');

// Prevent users from choosing a date in the past.
const today = new Date();
const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split('T')[0];
dateInput.min = localToday;

function updateVisitFields() {
  const selected = form.querySelector('input[name="visitType"]:checked')?.value;
  const needsSpecialist = selected === 'Specific condition';
  conditionFields.hidden = !needsSpecialist;
  ordinaryNote.hidden = needsSpecialist;
  conditionInput.required = needsSpecialist;
  specialistInput.required = needsSpecialist;
}
form.querySelectorAll('input[name="visitType"]').forEach(input => input.addEventListener('change', updateVisitFields));
updateVisitFields();

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

form.addEventListener('submit', event => {
  event.preventDefault();
  message.hidden = true;
  if (!form.checkValidity()) {
    form.reportValidity();
    message.textContent = 'Please complete all required fields and check your information.';
    message.hidden = false;
    return;
  }

  const data = new FormData(form);
  const considerations = data.getAll('considerations');
  const visitType = data.get('visitType');
  const specialist = visitType === 'Ordinary checkup' ? 'General Practitioner (assignment subject to availability)' : data.get('specialist');
  const priorityText = considerations.length ? 'Assistance / priority consideration indicated. Staff verification is required.' : 'No assistance / priority consideration selected.';
  const rows = [
    ['Patient', data.get('fullName')], ['Age', data.get('age')],
    ['Mobile', data.get('phone')], ['Email', data.get('email') || 'Not provided'],
    ['Visit type', visitType], ['Condition / reason', visitType === 'Specific condition' ? data.get('condition') : 'Ordinary checkup'],
    ['Doctor / specialist', specialist], ['Preferred schedule', `${data.get('preferredDate')} · ${data.get('preferredTime')}`],
    ['Assistance considerations', considerations.length ? considerations.join(', ') : 'None selected'],
    ['Queue note', priorityText]
  ];
  document.getElementById('confirmationText').textContent = `Thank you, ${data.get('fullName')}. Your request details are shown below for this demonstration.`;
  document.getElementById('requestSummary').innerHTML = rows.map(([label,value]) => `<p><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</p>`).join('');
  form.hidden = true;
  confirmation.hidden = false;
  confirmation.scrollIntoView({behavior:'smooth', block:'start'});
});

document.getElementById('newRequest').addEventListener('click', () => {
  form.reset();
  updateVisitFields();
  form.hidden = false;
  confirmation.hidden = true;
  message.hidden = true;
  dateInput.min = localToday;
  form.scrollIntoView({behavior:'smooth', block:'start'});
});
form.addEventListener('reset', () => {
  setTimeout(() => { updateVisitFields(); message.hidden = true; }, 0);
});
